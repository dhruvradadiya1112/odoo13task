{
    'name': "Multi lang",
    'summary': """
            """,
     "license": "GPL-2",
    'description': """
        Inventory Overvie
    """,
    'version': '13.0',
    'category': 'Inventory',
    'author': 'Dhruv Radadiya',
    'website': '',
    'sequence': 1,
    'depends': [
        'base','stock',
    ],
    'demo': [],
    'data': [
        
    ],
    'qweb': [
        
    ],
    'installable': True,
    'application': True,
    "auto_install": True,
}

